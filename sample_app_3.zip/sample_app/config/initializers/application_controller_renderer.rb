# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end
Refile.secret_key = '175c9b5fcaee23c8b536d7e83bb399de6dd93b1163901e5b27392d15f3a0698f1fc12359d4c537b2c1b285b985d3d3fafc194c96695c071fe282ddbdc0f39553'